﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Crystal Collazo");
            Console.WriteLine("I want to understand C# and be able to master it.");
            Console.WriteLine("I have taken CTI-110.");
            Console.WriteLine("The thing that was not covered in the class was Array/List/Dictionary or Classes.");
            Console.ReadLine();
        }
    }
}
